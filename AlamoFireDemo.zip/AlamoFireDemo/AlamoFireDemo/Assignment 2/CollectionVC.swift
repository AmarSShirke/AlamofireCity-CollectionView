//
//  CollectionVC.swift
//  AlamoFireDemo
//
//  Created by Amar Shirke on 25/04/21.
//

import UIKit
import Alamofire
import Kingfisher

class CollectionVC: UIViewController {

    @IBOutlet weak var brandsCV: UICollectionView!
    var brandArr = [NSDictionary]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        postApiCall()
    }
    
    func postApiCall() {
        
        let params = ["request":"brand_listing", "country": "india", "device_type":"ios"]
        AF.request("https://www.kalyanmobile.com/apiv1_staging/brand_listing.php?request=brand_listing&country=india&device_type=ios", method: .post, parameters: params).responseJSON { (resp) in
            print("Response here")
            
            if let dict = resp.value as? NSDictionary{
                print("RESPONSE HERE \(dict)")
                if let respCode = dict.value(forKey: "responseCode") as? String,let respMsg = dict.value(forKey: "responseMessage") as? String{
                    
                    if respCode == "success" {
                        
                        self.brandArr = dict.value(forKey: "brand") as! [NSDictionary]
                
                        print("respDict is \(self.brandArr[0])")
                        self.brandsCV.reloadData()
                        
                    }else{
                        print("ERR \(respMsg)")
                    }
                }
            }
        }
    }
}

extension CollectionVC: UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return brandArr.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CustomCVCell", for: indexPath) as! CustomCVCell
        
        let imgUrl = brandArr[indexPath.row].value(forKey: "brand_image_path")
        let url = URL(string: imgUrl as! String)
        cell.imgBrand.kf.setImage(with: url)
        cell.lblBrandName.text = brandArr[indexPath.row].value(forKey: "brand_name") as? String
        cell.lblBrandDescription.text = brandArr[indexPath.row].value(forKey: "brand_description") as? String
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        return CGSize(width: floor((collectionView.frame.size.width-20)/3) ,height:(collectionView.frame.size.width-20)/3)
        
       // return CGSize(width:collectionView.frame.size.width-10 ,height:100)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 5
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {

        if section == 0 {
            return UIEdgeInsets(top: 0, left: 5, bottom: 0, right: 5)
        }else{
            return UIEdgeInsets(top: 50, left: 5, bottom: 0, right: 5)
        }

    }

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        print("\(indexPath.section) \(indexPath.row)")
    }
}

