//
//  CustomCVCell.swift
//  AlamoFireDemo
//
//  Created by Amar Shirke on 25/04/21.
//

import UIKit

class CustomCVCell: UICollectionViewCell {
    
    @IBOutlet weak var imgBrand: UIImageView!
    @IBOutlet weak var lblBrandName: UILabel!
    @IBOutlet weak var lblBrandDescription: UILabel!
    
}
