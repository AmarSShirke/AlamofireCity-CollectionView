//
//  TVHeader.swift
//  AlamoFireDemo
//
//  Created by Amar Shirke on 27/04/21.
//

import UIKit

class TVHeader: UITableViewCell {

    @IBOutlet weak var CountryLbl: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
