//
//  Assignment1VC.swift
//  AlamoFireDemo
//
//  Created by Amar Shirke on 27/04/21.
//

import UIKit
import UIKit
import Alamofire

class Assignment1VC: UIViewController {
    
    @IBOutlet weak var cityTV: UITableView!
    
    @IBOutlet var errorView: UIView!
    @IBOutlet weak var errorBtn: UIButton!
    @IBOutlet weak var errorLbl: UILabel!
    
    var stateDict = NSDictionary()
    var cityArr = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        alamoFirePostExample()
    }
    
    func showError(msg: String){
        
        errorLbl.text = msg
        cityTV.backgroundView = errorView
        
    }
    
    @IBAction func retryBtnPress(_ sender: Any) {
        
        self.alamoFirePostExample()
    }
    
    func alamoFirePostExample(){
        
        if Connectivity.isConnectedToInternet() {
            
            print("Yes! internet is available.")
                
            let param = ["request":"city_listing","device_type":"ios","country":"india"]
            AF.request("https://www.kalyanmobile.com/apiv1_staging/city_listing.php", method: .post, parameters: param).responseJSON { (resp) in
                

                    
                    if let dict = resp.value as? NSDictionary{
                        if let respCode = dict.value(forKey: "responseCode") as? String, let respMsg = dict.value(forKey: "responseMessage") as? String{
                            if respCode == "success"{
                                let dataResp = resp.value as! NSDictionary
                                self.stateDict = dataResp.value(forKey: "city_array") as! NSDictionary
                                print("Success")
                                self.cityTV.reloadData()
                            }else{
    //                            DispatchQueue.main.async {
    //                                self.showError(msg: respMsg)
    //                            }
                            }
                        }
                    }
                
            }
            
        }else{
            DispatchQueue.main.async {
                self.showError(msg: "Internet connection not available, Please check your connection.")
            }
        }
        
        
       
    }
}


extension Assignment1VC: UITableViewDataSource, UITableViewDelegate{
    func numberOfSections(in tableView: UITableView) -> Int {
        return stateDict.allKeys.count
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let header = tableView.dequeueReusableCell(withIdentifier: "TVHeader") as! TVHeader
        header.CountryLbl.text = "\(stateDict.allKeys[section])"
        return header
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let arr = stateDict.allKeys as! [String]
        let arr1 = arr[section]
        cityArr = stateDict.value(forKey: "\(arr1)") as! [String]
        return cityArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomTVC") as! CustomTVC
        let arr = stateDict.allKeys as! [String]
        let arr1 = arr[indexPath.section]
        cityArr = stateDict.value(forKey: "\(arr1)") as! [String]
        cell.cityLbl.text = "\(cityArr[indexPath.row])"
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.1
    }
    
}


class Connectivity {
    class func isConnectedToInternet() ->Bool {
        return NetworkReachabilityManager()!.isReachable
    }
}

