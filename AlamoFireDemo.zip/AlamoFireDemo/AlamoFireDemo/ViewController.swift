//
//  ViewController.swift
//  AlamoFireDemo
//  Created by Amar Shirke on 25/04/21.

import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet weak var tblCities: UITableView!
    var respDict = [String: Any]()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        almofirePostExample()
    }
    
    func almofirePostExample(){
        
        let params = ["request":"city_listing", "device_type": "ios", "country":"india"]
        AF.request("https://www.kalyanmobile.com/apiv1_staging/city_listing.php", method: .post, parameters: params).responseJSON { (resp) in
            print("Response here")
            
            if let dict = resp.value as? NSDictionary{
                print("RESPONSE HERE \(dict)")
                if let respCode = dict.value(forKey: "responseCode") as? String,let respMsg = dict.value(forKey: "responseMessage") as? String{
                    
                    if respCode == "success" {
                        
                        self.respDict = dict.value(forKey: "city_array") as! [String : Any]
                        
                        print("respDict is \(Array(self.respDict)[0].key)")
                    }else{
                        print("ERR \(respMsg)")
                    }
                }
            }
        }
    }
    
}

/*
extension ViewController: UITableViewDelegate, UITableViewDataSource{
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return respDict.keys.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        //return respDict.keys[section]
        let index = 5 // Int Value
        return Array(respDict)[index].key

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        if self.hiddenSections.contains(section) {
            return 0
        }
        
        return self.respDict[section].count
   
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .default, reuseIdentifier: "cell")
        //cell.textLabel?.text = foodArr[indexPath.row]
        cell.textLabel?.text = foodArr[indexPath.section][indexPath.row]
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let sectionButton = UIButton()
        sectionButton.setTitle(foodTypeArr[section],for: .normal)
        sectionButton.backgroundColor = .systemBlue
        sectionButton.tag = section
        sectionButton.addTarget(self,
                                action: #selector(self.btnPress(sender:)),
                                for: .touchUpInside)

        return sectionButton
        
    }
    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        print("Row Press \(indexPath.section) \(indexPath.row)")
//
//        let alert = UIAlertController(title: "Your order", message: "Will deliver", preferredStyle: .alert)
//
//        let okAction = UIAlertAction(title: "OK", style: .default) { (action) in
//            print("okpress")
//        }
//        alert.addAction(okAction)
//
////        let cacelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
////        alert.addAction(cacelAction)
//
//        let cacelAction = UIAlertAction(title: "Cancel", style: .destructive, handler: nil)
//        alert.addAction(cacelAction)
//
//        present(alert, animated: true, completion: nil)
//    }
    
    @objc func btnPress(sender: UIButton) {
        let section = sender.tag
        
        func indexPathsForSection() -> [IndexPath] {
            var indexPaths = [IndexPath]()
            
            for row in 0..<self.foodArr[section].count {
                indexPaths.append(IndexPath(row: row,
                                            section: section))
            }
            
            return indexPaths
        }
        
        if self.hiddenSections.contains(section) {
            self.hiddenSections.remove(section)
            self.tblCustom.insertRows(at: indexPathsForSection(),
                                      with: .fade)
        } else {
            self.hiddenSections.insert(section)
            self.tblCustom.deleteRows(at: indexPathsForSection(),
                                      with: .fade)
        }
    }
}
*/
